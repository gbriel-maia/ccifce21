Arquivo zip gerado em: 27/11/2021 02:13:59 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Implementação de um TAD Lista