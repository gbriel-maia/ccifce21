#ifndef __HeapSort__h
#define __HeapSort__h
void mostrar_vetor(int *v, int l);
void preencher_vetor(int *v, int l);
void heap_criar(int *v, int i, int l);
void heapsort(int *v, int l);
#endif